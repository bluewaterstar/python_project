import pygame
from pygame.sprite import Sprite

class Bullet(Sprite):
    """管理飞船射出的子弹"""

    def __init__(self,axxx_game):
        """在飞船当前位置创建一个子弹对象"""
        super().__init__()

        self.screen = axxx_game.screen
        self.settings = axxx_game.settings

       # self.color = self.settings.bullet_color
        self.color = pygame.transform.scale(pygame.image.load("ship.bmp"),(30,30))
        # 在（0，0）处创建一个表示子弹的矩形，再设置正确的位置
        self.rect = pygame.Rect(0,0,self.settings.bullet_width,
                                 self.settings.bullet_height + 120)
        # self.rect.midbottom = axxx_game.ship.rect.midbottom
        self.rect.midbottom = axxx_game.ship.rect.midbottom



        # 存储用小数表示的子弹位置
        self.y = float(self.rect.y)



    def update(self):
        """向上移动子弹"""
        # 更新表示子弹位置的小数值
        self.y -= self.settings.bullet_speed
        # 更新表示子弹的rect的位置
        self.rect.y = self.y

    def draw_bullet(self):
        """在屏幕上绘制子弹"""
        #pygame.draw.rect(self.screen,self.color,self.rect)
        self.screen.blit(self.color,self.rect)
